
def hello_world():
    print("hello scratch A")
